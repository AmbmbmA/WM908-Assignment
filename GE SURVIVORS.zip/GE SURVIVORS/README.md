# GE SURVIVORS

## move

WASD

## auto atk
auto aiming the closest enemy

## AOE 

**cd:** 5s, once the cd is done, within the targeted area, **4(base)** enemies would shown as targeted based on their health **(highest)**

**press space:** auto attack around the player

**to aim:** click and hold **"left mouse button"** to aim then **"right mouse button"** to fire. OR you could hold **"J"** to aim aroung the player then press **"K"** to fire.

## Power and Level up

MAX LEVEL 10 starting from 0.

**Power up:**

level 1,3,5,7,9 increase auto shooting speed

level 2,4,6,8,10 increase AOE target number and radius


## ATTENTION!

scale the window would cause the mouse to shift
Please do not resize it.
